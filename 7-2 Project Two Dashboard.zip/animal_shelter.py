from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps
import json

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    # Initializing the MongoClient. This helps to access the MongoDB databases and collections. 
    def __init__(self,username,password):
        # Connect to MongoDB without authentication.
        #self.client = MongoClient('mongodb://localhost:46236')
        # Connect to MongoDB with authentication.
        self.client = MongoClient('mongodb://%s:%s@localhost:46236/?authMechanism=DEFAULT&authSource=AAC'%(username,password))
        self.database = self.client['AAC']

    # Create method
    def create(self, data):
        # Checks to ensure data parameter is Not empty
        if data is not None:
            # Inserts data as dictionary to the database (Python dictionary is identical to MongoDB document)
            self.database.animals.insert(data)
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False
            
    # Read method
    def read_all(self, data):
        # Checks to ensure query data parameter is Not empty
        if data is not None:
            # Returns a cursor pointing to a list of results (Documents)
            return self.database.animals.find(data, {'_id':False})
        else:
            raise Exception("Nothing to search, because data parameter is empty")
    
    # Read method (Returns only a single document)
    def read(self, data):
        # Checks to ensure query data parameter is Not empty
        if data is not None:
            # Checks for the existence of a document
            if self.database.animals.find_one(data):
                # Returns only one document as a Python dictionary
                return self.database.animals.find_one(data)
            else:
                print("No record on file")
        else:
            print("Nothing to search, because data parameter is empty")
       
    # Update method
    def update(self, data, update_data):
        # Checks to ensure query data parameter is Not empty
        if data is not None:
            # Checks to ensure at least a single matched document exist
            if (self.database.animals.find_one(data) != None):
                # Updates all matched documents
                result = self.database.animals.update_many(data, {"$set": update_data})
                return ("Updated Record(s): " + json.dumps(result.modified_count))
            else:
                print("No record on file")
        else: 
            print("Nothing to update, because data parameter is empty")
            
    # Delete method
    def delete(self, data):
        # Checks to ensure query data parameter is Not empty
        if data is not None:
            # Checks to ensure at least a single matched document exist
            if (self.database.animals.find_one(data) != None):
                # Deletes all matched documents
                result = self.database.animals.delete_many(data)
                return ("Deleted Record(s): " + json.dumps(result.deleted_count))
            else:
                print("No record on file")
        else: 
            print("Nothing to delete, because data parameter is empty")
                    